#include <iostream>
#include <math.h>
using namespace std;
//p2-khai bao
void gptb2();
//p3-dinh nghia
void gptb2()
{
    cout<<"Giai pt bac 2: moi ban nhap 3 he so a,b,c"<<endl;
    float a,b,c;
    cin>>a; cin>>b; cin>>c;
    float delta=b*b-4*a*c;
    if(delta<0){  cout<<"Phuong trinh vo nghiem"<<endl; }
    else if(delta==0){ cout<<"pt co 1 nghiem "<<-b/(2*a)<<endl; }
    else 
    {
        cout<<"PT co 2 nghiem x1="<<(-b+sqrt(delta))/(2*a)<<endl;
        cout<<" va x2="<<(-b-sqrt(delta))/(2*a)<<endl;
    }
}
int main()
{
    //p4-goi ham
    gptb2();
    return 0;
}
