#include <iostream>
#include <math.h>
using namespace std;
//p2-Khai bao ham
void hocluc();
void ptb1();
void ptb2();
void tiendien();
void menu();
//p3-dinh nghia ham

void hocluc()
{
   cout<<"Chuong trinh tinh hoc luc"<<endl;
   cout<<"Moi ban nhap vao diem"<<endl;
   float diem;
   cin>>diem;
   if(diem>=9)
   {
       cout<<"Xuat sac"<<endl;
   }
   else if(diem>=8)
   {
       cout<<"Gioi"<<endl;
   }
   else if(diem>=6.5)
   {
       cout<<"kha"<<endl;
   }
   else 
   {
       cout<<"Trung binh hoac Yeu kem"<<endl;
   }
   menu();
}
void ptb1()
{
    cout<<"Giai pt bac 1"<<endl;
    cout<<"moi ban nhap 2 he so a,b";
    float a,b;
    cin>>a;
    cin>>b;
    if(a==0)
    {
        if(b==0)
        {
            cout<<"PT vo so nghiem"<<endl;
        }
        else
        {
            cout<<"PT vo nghiem"<<endl;
        }
    }
    else
    {
        cout<<"PT co nghiem x="<<-b/a<<endl;
    }
    menu();
}
void ptb2()
{
    cout<<"Giai ptb2"<<endl;
    cout<<"Moi ban nhap 3 he so a,b,c"<<endl;
    float a,b,c;
    cin>>a; cin>>b; cin>>c;
    float delta=b*b-4*a*c;
    if(delta<0)
    {
        cout<<"PT vo nghiem"<<endl;
    }
    else if(delta=0)
    {
        cout<<"PT co nghiem kep x="<<-b/(2*a);
    }
    else
    {
        cout<<"PT co 2 nghiem x1="<<(-b+sqrt(delta))/(2*a)<<endl;
        cout<<" va x2="<<(-b-sqrt(delta))/(2*a)<<endl;
    }
    menu();
}
void menu()
{
    cout<<"1.Tinh Hoc luc"<<endl;
    cout<<"2.Giai ptb1"<<endl;
    cout<<"3.Giai ptb2"<<endl;
    cout<<"4.Tinh tien dien"<<endl;
    int luachon;
    cin>>luachon;
    switch(luachon)
    {
        case 1:         //nhap so 1
            hocluc();   //thi goi den hocluc
            break;      //thoat
        case 2:         //nhap vao so 2
            ptb1();     //thi goi ham ptb1
            break;      //thoat
        case 3:
            ptb2();
            break;
    }
}
int main()
{
    //p4.goi ham
    menu();
    return 0;
}
