#include <iostream>
#include <math.h>
using namespace std;
//P2-khai bao
void gptb1();
//p3-dinh nghia
void gptb1()
{
    cout<<"Giai phuong trinh bac 1"<<endl;
    cout<<"Moi ban nhap vao 2 he so a,b"<<endl;
    float a,b;
    cin>>a; cin>>b;
    if(a==0)
    {
        if(b==0)
        {
            cout<<"Phuong trinh co vo so nghiem"<<endl;
        }
        else
        {
            cout<<"PT vo nghiem"<<endl;
        }
    }
    else
    {
        cout<<"PT co nghiem "<<-b/a<<endl;
    }
}
int main()
{
    //p4-goi ham
    gptb1();
    return 0;
}
