#include <iostream>
#include <math.h>
using namespace std;
//P2-Khai bao ham
void hocluc();
//P3-Dinh nghia ham
void hocluc()
{
    cout<<"Xep loai hoc luc"<<endl;
    cout<<"Moi ban nhap diem"<<endl;
    float diem;
    cin>>diem;
    if(diem>=9)
    {
        cout<<"Xuat sac"<<endl;
    }
    else if(diem>=8)
    {
        cout<<"Gioi"<<endl;
    }
    else if(diem>=6.5)
    {
        cout<<"Kha"<<endl;
    }
    else if(diem>=5)
    {
        cout<<"Trung binh"<<endl;
    }
    else
    {
        cout<<"Yeu kem"<<endl;
    }
}
int main()
{
    //p4- goi ham
     hocluc();
    return 0;
}
