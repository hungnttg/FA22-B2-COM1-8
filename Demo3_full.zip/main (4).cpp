#include <iostream>
#include <math.h>
using namespace std;
void menu();
void menu()
{
    cout<<"1. Tinh hoc luc"<<endl;
    cout<<"2. Giai ptb1"<<endl;
    cout<<"3. Giai ptb2"<<endl;
    cout<<"4. Tinh tien dien"<<endl;
    int chuongtrinh;
    cin>>chuongtrinh;
    switch(chuongtrinh)
    {
        case 1:
            //goi ham 1
            break;
        case 2:
            //goi ham 2
            break;
        case 3:
            //goi ham 3
            break;
        case 4:
            //goi ham 4
            break;
    }
}
int main()
{
    menu();
    return 0;
}
