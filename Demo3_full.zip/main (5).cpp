#include <iostream>
#include <math.h>
using namespace std;
void menu();
void hocluc();
void gptb1();
void gptb2();
void tinhtiendien();
void menu()
{
    cout<<"1. Tinh hoc luc"<<endl;
    cout<<"2. Giai ptb1"<<endl;
    cout<<"3. Giai ptb2"<<endl;
    cout<<"4. Tinh tien dien"<<endl;
    int chuongtrinh;
    cin>>chuongtrinh;
    switch(chuongtrinh)
    {
        case 1:
            //goi ham 1
            hocluc();
            break;
        case 2:
            //goi ham 2
            gptb1();
            break;
        case 3:
            //goi ham 3
            gptb2();
            break;
        case 4:
            //goi ham 4
            tinhtiendien();
            break;
    }
}
void hocluc()
{
    cout<<"Xep loai hoc luc"<<endl;
    cout<<"Moi ban nhap diem"<<endl;
    float diem;
    cin>>diem;
    if(diem>=9)
    {
        cout<<"Xuat sac"<<endl;
    }
    else if(diem>=8)
    {
        cout<<"Gioi"<<endl;
    }
    else if(diem>=6.5)
    {
        cout<<"Kha"<<endl;
    }
    else if(diem>=5)
    {
        cout<<"Trung binh"<<endl;
    }
    else
    {
        cout<<"Yeu kem"<<endl;
    }
    menu();
}
void gptb1()
{
    cout<<"Giai phuong trinh bac 1"<<endl;
    cout<<"Moi ban nhap vao 2 he so a,b"<<endl;
    float a,b;
    cin>>a; cin>>b;
    if(a==0)
    {
        if(b==0)
        {
            cout<<"Phuong trinh co vo so nghiem"<<endl;
        }
        else
        {
            cout<<"PT vo nghiem"<<endl;
        }
    }
    else
    {
        cout<<"PT co nghiem "<<-b/a<<endl;
    }
    menu();
}
void gptb2()
{
    cout<<"Giai pt bac 2: moi ban nhap 3 he so a,b,c"<<endl;
    float a,b,c;
    cin>>a; cin>>b; cin>>c;
    float delta=b*b-4*a*c;
    if(delta<0){  cout<<"Phuong trinh vo nghiem"<<endl; }
    else if(delta==0){ cout<<"pt co 1 nghiem "<<-b/(2*a)<<endl; }
    else 
    {
        cout<<"PT co 2 nghiem x1="<<(-b+sqrt(delta))/(2*a)<<endl;
        cout<<" va x2="<<(-b-sqrt(delta))/(2*a)<<endl;
    }
    menu();
}
void tinhtiendien()//dinh nghia
{
    cout<<"Tinh tien dien: Moi ban nhap vao so dien"<<endl;
    int sodien;
    cin>>sodien;
    if(sodien<=50){ cout<<"Tien dien la "<<sodien*1678<<endl; }
    else if(sodien<=100){ cout<<"Tien dien la "<<50*1687+(sodien-50)*1734<<endl; }
    else if(sodien<=200){ cout<<"Tien dien la "<<50*1678+50*1734+(sodien-100)*2014<<endl;}
    else if(sodien<=300){ cout<<"Tien dien la "<<50*1678+50*1734+100*2014+(sodien-200)*2536<<endl;}
    else { cout<<"Tien dien la "<<50*1678+50*1734+100*2014+100*2536+(sodien-300)*2834<<endl;}
    menu();
}
int main()
{
    menu();
    return 0;
}
