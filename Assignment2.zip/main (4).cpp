#include <iostream>
using namespace std;
float hamtralai(float tienvay,float laisuat,int kyhan);
float hamtralai(float tienvay,float laisuat,int kyhan)
{
    return (laisuat/100)*tienvay + tienvay/12;
}
int main()
{
    cout<<"Moi nhap tien vay, lai suat (5), ky han (1,2,..12)"<<endl;
    float tienvay; float laisuat; int kyhan;
    cin>> tienvay; cin>>laisuat; cin>>kyhan;
    float tienvaygoc=tienvay;
    for(int i=1;i<=12;i++)
    {
        
        cout<<"Ky han \t Lai phai tra \t Goc phai tra \t So tien phai tra \t So tien con lai"<<endl;
        cout<<i<<"\t\t"<<(laisuat/100)*tienvay<<"\t\t"<<tienvaygoc/12<<"\t\t"
        <<(laisuat/100)*tienvay+tienvaygoc/12<<"\t\t"<<tienvaygoc-(tienvaygoc/12)*i<<endl;
        tienvay=tienvay-(tienvay/12)*i;
    }

    return 0;
}
