#include <iostream>
#include <math.h>
using namespace std;
float laitietkiem(float tiengui, float laisuat, int nam);
float laitietkiem(float tiengui, float laisuat, int nam)
{
    return tiengui*pow((1+laisuat),nam);
}
int main()
{
    cout<<"Moi nhap tien gui (100), lai suat (0.05), so nam (1,2,3)"<<endl;
    float tiengui,laisuat;
    int nam;
    cin>>tiengui; cin>>laisuat; cin>>nam;
    cout<<"Nam \t Von"<<endl;
    for(int i=1; i<=nam;i++)
    {
        cout<<i<<"\t"<<laitietkiem(tiengui,laisuat,i)<<endl;
    }
    return 0;
}
