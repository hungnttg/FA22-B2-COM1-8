#include <iostream>
using namespace std;
int main()
{
    cout<<"Doi tien"<<endl;
    const int MAX=6;
    int loaitien[MAX]={500,200,100,50,20,10};
    cout<<"Moi nhap so tien"<<endl;
    int sotien; cin>>sotien;
    int soto;
    for(int i=0;i<MAX;i++)
    {
        soto=sotien/loaitien[i];
        cout<<"Co "<<soto<<" loai tien "<<loaitien[i]<<endl;
        sotien=sotien%loaitien[i];
    }

    return 0;
}
