//P1.Lien ket thu vien
#include <iostream>
#include <math.h>
using namespace std;
//P2. Khai bao ham
void menu();
void kiemTraSoNguyen();
void USC_BSC();
//P3. Dinh nghia ham
void menu()
{
    cout<<"--------Asssignment--------"<<endl;
    cout<<"1. Kiem tra so nguyen"<<endl;
    cout<<"2. Tim USC, BSC"<<endl;
    int chuongtrinh;                        //khai bao bien chuong trinh                    
    cin>>chuongtrinh;                       //nhap lieu vao bien
    switch(chuongtrinh)                     //kiem tra bien bang bao nhieu
    {
        case 1:                             //bien=1
            kiemTraSoNguyen();              //goi ham kiemTraSoNguyen
            break;                          //thoat
        case 2:                             //bien=2
            USC_BSC();                      //goi ham USC_BSC
            break;                          //thoat
    }
}
void kiemTraSoNguyen()
{
    cout<<"Chuong trinh kiem tra so"<<endl;
    cout<<"Moi ban nhap 1 so nguyen "<<endl;
    int x;                                  //khai bao bien x
    cin>>x;                                 //nhap gia tri vao bien x
    if(x==(int)x)                           //neu x bang phan nguyen cua x
    {
        cout<<x<<" la so nguyen"<<endl;
    }
    else                                    //nguoc lai
    {
        cout <<x<<" khong phai so nguyen"<<endl;
    }
    menu();                                 //goi ham menu
}
int USCLN(int a,int b)//uoc so chung lon nhat cua a va b
{
    if(b==0)            //neu b=0
        return a;       //uscln =0
                    //nguoc lai neu b khac 0
        return USCLN(b,a%b);   //USCLN cua b va phep chia lay phan du cua a/b

}
int BSCNN(int a,int b) //boi so chung nho nhat cua a va b
{
    return (a*b)/USCLN(a,b);//a nhan b chia cho USCLN cua a va b
}
void USC_BSC()
{
    cout<<"Moi ban nhap 2 so"<<endl;
    int a,b;                        //khai bao 2 bien a,b
    cin>>a;                         //nhap bien a
    cin>>b;                         //nhap bien b
    cout<<"USCLN la "<<USCLN(a,b)<<endl;
    cout<<"BSCNN la "<<BSCNN(a,b)<<endl;
    menu();                         //goi ham menu
}
int main()
{
    menu();                         //chay chuong trinh

    return 0;
}
