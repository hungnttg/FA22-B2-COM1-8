#include <iostream>
#include <math.h>
using namespace std;
void menu();//1.khai bao
void menu()//3.dinh nghia
{
    cout<<"1. trung binh tong"<<endl;
    cout<<"2. So nguyen to"<<endl;
    cout<<"3. So chinh phuong"<<endl;
    int chuongtrinh; 
    cin>>chuongtrinh;
    switch(chuongtrinh)
    {
        case 1:
            //ham();
            break;
        case 2:
            //ham1();
            break;
        case 3:
            //ham2();
            break;
    }
}
int main()
{
    menu();//3. goi ham
    return 0;
}
