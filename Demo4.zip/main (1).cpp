#include <iostream>
#include <math.h>
using namespace std;
void ham();//1.khai bao
void ham()//3.dinh nghia
{
    cout<<"Kiem tra so nguyen to: Moi nhap 1 so nguyen"<<endl;
    int n; cin>>n;
    int dem=0;
    for(int i=2; i<n;i++)
    {
        if(n%i==0)//neu chia het cho 1 so khac
        {
            dem++;//dem tu cong len 1
        }
    }
    if(dem==0){ cout<<n<<" la so nguyen to"<<endl; }
    else { cout<<n<<" khong phai so nguyen to"<<endl;}
}
int main()
{
    ham();//3. goi ham
    return 0;
}
