#include <iostream>
#include <math.h>
using namespace std;
void ham();//1.khai bao
void ham()//3.dinh nghia
{
    cout<<"Trung binh tong: Moi nhap 2 bien max,min"<<endl;
    int max,min;
    cin>>min; cin>>max;         //nhap min, max tu ban phim
    int tong=0;                 //ban đầu tổng = 0
    int dem=0;                  //đếm =0
    for(int i=min;i<=max;i++)
    {
        if(i%2==0)              //kiem tra xem i co chia het cho 2 khong
        {
            tong =tong+ i;      //neu chia het cho 2 thi cong don vao tong
            dem = dem +1;       // cong bien dem them 1
        }
    }
    float tb = tong/dem;        //trung binh tong
    cout<<"Trung binh tong la "<<tb<<endl;
}
int main()
{
    ham();//3. goi ham
    return 0;
}
