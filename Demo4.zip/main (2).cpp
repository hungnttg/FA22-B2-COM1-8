#include <iostream>
#include <math.h>
using namespace std;
void ham2();//1.khai bao
void ham2()//3.dinh nghia
{
    cout<<"Kiem tra so chinh phuong: Moi nhap 1 so nguyen"<<endl;
    int n; cin>>n;
    int dem=0;
    int i=0;
    while(i<n)
    {
        if(i*i==n)//n khai can bac 2 la 1 so nguyen
        {
            dem++;
        }
        i++;
    }
    if(dem==0){ cout<<n<<" khong la so chinh phuong"<<endl; }
    else { cout<<n<<" la so chinh phuong"<<endl;}
}
int main()
{
    ham2();//3. goi ham
    return 0;
}
