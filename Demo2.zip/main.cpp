#include <iostream>
using namespace std;

int main()
{
    cout<<"Moi ban nhap 2 so"<<endl;    //in ra man hinh
    int a,b;                            //khai bao 2 bien a,b
    cin>>a;                             //nhap du lieu vao bien a
    cin>>b;                             //nhap du lieu vao bien b
    int tong=a+b;                       //tinh tong
    int hieu=a-b;                       //tinh hieu
    cout<<"Tong la "<<tong<<endl;       //in ra tong
    cout <<"Hieu la "<<hieu<<endl;      //in ra hieu
                                        //system("pause");
    return 0;                           //ket thuc chuong trinh
}
