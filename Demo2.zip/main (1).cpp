#include <iostream>
using namespace std;

int main()
{
    cout<<"Chuong trinh tinh chu vi, dien tich hcn"<<endl;
    cout<<"Moi ban nhap vao chieu dai, chieu rong"<<endl;
    float dai,rong;                                         //khai bao dai,rong
    cin>>dai;                                               //nhap lieu chieu dai
    cin>>rong;                                              //nhap lieu chieu rong
    float chuvi=(dai+rong)*2;                               //tinh chu vi
    float dientich=dai*rong;                                //tinh dien tich
    cout<<"Chu vi la "<<chuvi<<endl;
    cout<<"Dien tich la "<<dientich<<endl;
    
    return 0;                           //ket thuc chuong trinh
}
