#include <iostream>
using namespace std;

int main()
{
    cout<<"Chu vi dien tich hinh tron"<<endl;
    const float PI=3.14;
    cout<<"Moi ban nhap ban kinh"<<endl;
    float r;                            //khai bao ban kinh
    cin>>r;                             //nhap du lieu vao ban kinh
    float chuvi = 2*PI*r;
    float dientich = PI*r*r;
    cout<<"Chu vi la "<<chuvi<<endl;
    cout<<"Dien tich la "<<dientich<<endl;
    return 0;                           //ket thuc chuong trinh
}
