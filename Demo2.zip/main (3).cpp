#include <iostream>
using namespace std;

int main()
{
    cout<<"tinh diem trung binh"<<endl;
    cout<<"Moi ban nhap diem Toan, ly, hoa"<<endl;
    float toan,ly,hoa;                              //khai bao 3 bien
    cin>>toan;                                      //nhap vao bien toan
    cin>>ly;                                        //nhap vao bien ly
    cin>>hoa;                                       //nhap vao bien hoa
    float trungbinh=(toan*3+ly*2+hoa*1)/6;          //tinh diem trung binh
    cout<<"Diem trung binh la "<<trungbinh<<endl;
    return 0;                                       //ket thuc chuong trinh
}
