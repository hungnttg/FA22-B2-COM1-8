#include <iostream>
using namespace std;
void Swap(int &a, int &b){
    int temp = a;
    a = b;
    b = temp;
}

void InterchangeSort(int a[], int n){	
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
	        if(a[i] > a[j])  //nếu có nghịch thế thì đổi chỗ
		        Swap(a[i], a[j]);
}
int main()
{
    cout<<"Nhap vao 1 mang 5 phan tu"<<endl;
    int a[5];
    for(int i=0;i<5;i++)
    {
        cin>>a[i];
    }
    cout<<"Truoc khi sap xep"<<endl;
    for(int i=0;i<5;i++)
    {
        cout<<a[i]<<" ";
    }
    InterchangeSort(a,5);
    cout<<endl<<"SAU khi sap xep"<<endl;
    for(int i=0;i<5;i++)
    {
        cout<<a[i]<<" ";
    }
    return 0;
}
