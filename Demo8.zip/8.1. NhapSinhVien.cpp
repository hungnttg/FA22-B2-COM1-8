#include <iostream>
#include <string>
using namespace std;
int main()
{
    struct hocsinh
    {
        string hoten;
        float dt, dl, dh;
    };
    hocsinh hs[100];
    int n;
    cout << "Nhap so sinh vien: ";
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cout << "Nhap Ho Ten sv: ";
        cin.ignore(1);
        getline(cin, hs[i].hoten);
        fflush(stdin);
        cout << "Nhap diem Toan: ";
        cin >> hs[i].dt;
        cout << "Nhap diem Ly: ";
        cin >> hs[i].dl;
        cout << "Nhap diem Hoa: ";
        cin >> hs[i].dh;
    }
    for (int j = 1; j <= n;j++)
    {
        cout << "\n\nHo Va Ten : " << hs[j].hoten << "\n Diem Toan: " << hs[j].dt
            << "\n Diem Ly " << hs[j].dl << "\n Diem Hoa: " << hs[j].dh << endl;

    }
    return 0;
}