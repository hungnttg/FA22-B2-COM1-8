
#include <iostream>

using namespace std;

int main()
{
    cout<<"Xin moi ban nhap gia tri x="; //đưa ra thông báo
    int x;//khai báo biến x
    cin>>x;//nhập giá trị vào biến x
    cout<<"Gia tri ban vua nhap la "<<x<<endl;
    return 0;
}
