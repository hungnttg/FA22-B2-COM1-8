
#include <iostream>

using namespace std;

int main()
{
    int x = 5;//khai báo biến nguyên x = 5
    float y = 2.3;//khai báo biến số thực y = 2.2
    //in ra biến x, y
    cout<<"x có giá trị là "<< x <<endl;
    cout<<"y có giá trị là "<< y << endl;
    return 0;
}
