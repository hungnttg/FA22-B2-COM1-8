
#include <iostream>

using namespace std;

int main()
{
    //khai báo biến kiểu số nguyên
    int x = 5;
    //in ra biến x
    cout<<"x nhan gia tri la "<<x;
    return 0;
}
