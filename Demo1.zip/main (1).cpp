
#include <iostream>

using namespace std;

int main()
{
    //biến số a nhận giá trị là 1 văn bản
    string a = "day la lop ca 4 buoi chieu";
    //in ra biến a
    cout<<a;

    return 0;
}
