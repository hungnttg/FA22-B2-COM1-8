
#include <iostream>

using namespace std;

int main()
{
   cout<<"Xin chao lop WEB18313";

    return 0;
}
