
#include <iostream>

using namespace std;

int main()
{
    cout<<"Xin moi ban nhap gia tri x="; //đưa ra thông báo
    int x;//khai báo biến x
    cin>>x;//nhập giá trị vào biến x
    x = x+1; //tăng x lên 1
    cout<<"Gia tri ban vua nhap la "<<x+2<<endl;
    return 0;
}
