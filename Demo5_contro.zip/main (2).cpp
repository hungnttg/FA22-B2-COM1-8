#include <iostream>
using namespace std;
void minmax(int* a, int* b, int* c);
void minmax(int* a, int* b, int* c)
{
    int min=*a;
    int max=*a;
    if(*b>max){ max=*b;}
    if(*c>max){ max=*c;}
    if(*b<min){ min=*b;}
    if(*c<min){ min=*c;}
    cout<<"min la "<<min<<" ma max la "<<max<<endl;
}
int main()
{
    cout<<"Moi nhap a,b,c"<<endl;
    int a,b,c;
    cin>>a; cin>>b; cin>>c;
    minmax(&a,&b,&c);//truyen tham chieu (truyen dia chi cua bien)
    return 0;
}
