#include <iostream>
using namespace std;
int timmax(int* a, int* b, int* c);
int timmax(int* a, int* b, int* c)
{
    int max=*a;
    if(*b>max){ max=*b; }
    if(*c>max){ max=*c; }
    return max;
}
int main()
{
    cout<<"Moi nhap 3 so a,b,c"<<endl;
    int a,b,c; cin>>a; cin>>b; cin>>c;
    int max= timmax(&a, &b, &c);//truyen tham chieu
    cout<<"Max cua 3 so vua nhap la "<<max;
    return 0;
}
