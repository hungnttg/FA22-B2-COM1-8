#include <iostream>
using namespace std;
int namnhuan(int* nam);
int namnhuan(int* nam)
{
    if(*nam%400==0||*nam%4==0)
    {
        if(*nam%100!=0)
        {
            cout<<*nam<<" la nam nhuan"<<endl;
        }
        else {cout<<*nam<<" khong phai nam nhuan "<<endl; }
    }
    else {cout<<*nam<<" khong phai nam nhuan "<<endl; }
    return *nam;
}

int main()
{
    cout<<"moi ban nhap vao nam"<<endl;
    int nam; cin>>nam;
    namnhuan(&nam);
    return 0;
}
