#include <iostream>
using namespace std;
void doicho(int a, int b);
void doicho(int a, int b)
{
    int tam = a;
    a=b;
    b=tam;
}
int main()
{
    cout<<"Moi nhap a,b"<<endl;
    int a,b;
    cin>>a; cin>>b;
    cout<<"TRUOC khi doi cho a="<<a<<" va b="<<b<<endl;
    doicho(a, b);//gọi hàm kiểu tham trị (truyền giá trị vào biến)
    cout<<"SAU khi doi cho a="<<a<<" va b="<<b<<endl;
    return 0;
}
