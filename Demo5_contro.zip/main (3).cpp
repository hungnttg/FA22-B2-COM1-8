#include <iostream>
using namespace std;
void namnhuan(int nam);
void namnhuan(int nam)
{
    if(nam%400==0||nam%4==0)
    {
        if(nam%100!=0)
        {
            cout<<nam<<" la nam nhuan"<<endl;
        }
        else
        {
            cout<<nam<<" khong la nam nhuan"<<endl;
        }
    }
    else {cout<<nam<<" khong la nam nhuan"<<endl;}
}
int main()
{
    cout<<"Moi nhap nam"<<endl;
    int nam; cin>>nam;
    namnhuan(nam);
    return 0;
}
