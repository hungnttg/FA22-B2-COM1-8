#include <iostream>
using namespace std;
void doicho(int* a, int* b);
void doicho(int* a, int* b)
{
    int tam=*a; *a=*b; *b=tam; //thuc hien doi cho
}
int main()
{
    cout<<"Moi nhap a,b"<<endl;
    int a,b; cin>>a; cin>> b;
    cout<<"Truoc khi doi cho: a= "<<a<<" va b="<<b<<endl;
    doicho(&a,&b); //goi ham bang tham chieu (truyen dia chi cua bien)
    cout<<"SAU khi doi cho: a= "<<a<<" va b="<<b<<endl;
    return 0;
}
