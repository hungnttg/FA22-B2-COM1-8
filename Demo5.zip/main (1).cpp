#include <iostream>
using namespace std;
void doiCho(int* a,int* b);//khai bao ham
void doiCho(int* a,int* b)//dinh nghia ham
{
    int tam;
    tam=*a;
    *a=*b;
    *b=tam;
}
int main()
{
    cout<<"Nhap a,b"<<endl;
    int a,b; cin>>a; cin>>b;
    //---
    cout<<"Truoc khi doi cho"<<endl;
    cout<<"a= "<<a<<endl;
    cout<<"b= "<<b<<endl;
    //---
    doiCho(&a,&b);//goi ham doi cho
    cout<<"Sau khi doi cho"<<endl;
    cout<<"a= "<<a<<endl;
    cout<<"b= "<<b<<endl;
    return 0;
}
