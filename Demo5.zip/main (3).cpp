#include <iostream>
using namespace std;
void namnhuan();//khai bao
void namnhuan()
{
    cout<<"Moi nhap vao nam"<<endl;
    int nam; cin>>nam;
    if(nam%400==0)//chia het cho 400
    {
        cout<<nam<<" la nam nhuan"<<endl;
    }
    else if(nam%4==0 && nam%100 != 0)
    {
        cout<<nam<<" la nam nhuan"<<endl;
    }
    else {
        cout<<nam<<" khong phai nam nhuan"<<endl;
    }
}
int main()
{
    namnhuan();
    return 0;
}
