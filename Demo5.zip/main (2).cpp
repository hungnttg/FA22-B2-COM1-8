#include <iostream>
using namespace std;
void sosanh();//khai bao
void sosanh()
{
    cout<<"Moi nhap so1, so2, so3"<<endl;
    int so1,so2,so3;
    cin>>so1;   cin>>so2;   cin>>so3;
    int max=so1; //giả sử số 1 lớn nhất
    if(so2>max){ max=so2;}
    if(so3>max){ max=so3;}
    cout<<"Max la "<<max<<endl;
    
}
int main()
{
    sosanh();
    return 0;
}
