#include <iostream>
#include <cstring>
#include <string>

using namespace std;

int main()
{
    cout<<"Sap xep chuoi: Moi banj nhap 1 chuoi"<<endl;
    char str[5]; //khai bao mang ky tu
    for(int i=0;i<5;i++)//nhap du lieu vao mang ky tu
    {
        cin>>str[i];
    }
    cout <<"Chuoi truoc khi sap xep: "<<str<<endl; //in ra
    //sap xep
    char tam;
    for(int i=0;i<strlen(str);i++)
    {
        for(int j=0;j<strlen(str);j++)
        {
            if(str[i]<str[j])
            {
                tam=str[i];
                str[i]=str[j];
                str[j]=tam;
            }
        }
    }
    cout<<"Sau khi doi cho;"<<endl;
    cout<<str;
    return 0;
}
