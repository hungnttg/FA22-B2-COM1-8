#include <iostream>
#include <string>
using namespace std;

int main()
{
    cout<<"Dem nguyen am, phụ am: Moi ban nhap ho ten"<<endl;
    string s;           //khai bao bien
    cin>>ws;            //xu ly khoang trang
    getline(cin,s);     //nhap chuoi vao bien
    int dem=0;          //tong so ky tu
    int demnguyenam=0;  //so luong nguyen am
    int demphuam=0;     //so luong phu am
    int demdaucach=0;
    while(s[dem]!='\0') //neu khong phai ky tu enter
    {
        dem++;          //nhap 1 ky tu thi dem 1 lan
        if(s[dem]=='a'||s[dem]=='e'||s[dem]=='o'||s[dem]=='i'||s[dem]=='u')
        {
            demnguyenam++; //neu la nguyen am, cong so luong vao nguyen am
        }
        if(s[dem]==' ')
        {
            demdaucach++;
        }
    }
    cout<<"So luong nguyen am la "<<demnguyenam<<endl;
    cout<<"So luong phu am: "<<dem-demnguyenam-demdaucach<<endl;
    return 0;
}
