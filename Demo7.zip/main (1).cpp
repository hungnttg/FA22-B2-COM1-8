#include <iostream>
#include <string>
using namespace std;

int main()
{
    cout<<"Dang nhap: Moi nhap User, pass"<<endl;
    string user="admin";
    string pass="123456";
    string u;
    cin>>ws;
    getline(cin,u);
    string p;
    cin>>ws;
    getline(cin,p);
    while(user!=u || pass!=p)
    {
        cout<<"sai user hoac pass"<<endl;
        cout<<"moi nhap lai user, pass"<<endl;
        cin>>ws;
        getline(cin,u);
        cin>>ws;
        getline(cin,p);
    }
    cout<<"Dang nhap thanh cong"<<endl;
    return 0;
}
