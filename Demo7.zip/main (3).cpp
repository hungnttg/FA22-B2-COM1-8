#include <iostream>
#include <string>

using namespace std;

int main()
{
    cout<<"Chuong trinh nhap san pham"<<endl;
    cout<<"Moi ban nhap ma san pham"<<endl;
    //nhap so
    int masp;
    cin>>masp;
    //nhap chuoi
    cout<<"Moi ban nhap ten san pham"<<endl;
    string tensp;
    cin>>ws;
    getline(cin,tensp);
    //in ra thong tin vua nhap
    cout<<"Thong tin ban vua nhap"<<endl;
    cout<<"Ma SP: "<<masp<<endl;
    cout<<"Ten SP: "<<tensp<<endl;

    return 0;
}
